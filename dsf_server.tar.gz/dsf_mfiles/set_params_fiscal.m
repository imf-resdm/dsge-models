lambda = 0;
lambda1 = 0.25;
lambda2 = 0.02;
lambda3 = 0.25;
lambda4 = 0.02;
theta_hbar = 1;
theta_Tbar = 1;
hbar = 0.25;
Tbar = 0.10;
save("params.mat", "lambda", "lambda1", "lambda2", "lambda3", "lambda4", "theta_hbar", "theta_Tbar", "hbar", "Tbar", "-append")
